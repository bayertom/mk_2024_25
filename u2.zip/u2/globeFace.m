function [] = globeFace(umin, umax, vmin, vmax, Du, Dv, du, dv, R, uk, vk, s0, proj, ub, vb)
    % Create graticule
    [XM, YM, XP, YP] = graticule(umin, umax, vmin, vmax, Du, Dv, du, dv, R, uk, vk, s0, proj);
    
    % Draw graticule
    hold on;
    plot(XM', YM', 'k');
    plot(XP', YP', 'k');
    axis equal;
    
    % Draw continent
    s0 = 0;
    file = '/MATLAB Drive/continents_points/eur.txt';
    [XC, YC] = continent(R, uk, vk, s0, proj, file);
    plot(XC, YC,'b');

    % Draw continent
    s0 = 0;
    file = '/MATLAB Drive/continents_points/amer.txt';
    [XC, YC] = continent(R, uk, vk, s0, proj, file);
    plot(XC, YC,'b');

    % Draw continent
    s0 = 0;
    file = '/MATLAB Drive/continents_points/anta.txt';
    [XC, YC] = continent(R, uk, vk, s0, proj, file);
    plot(XC, YC,'b');

    % Draw continent
    s0 = 0;
    file = '/MATLAB Drive/continents_points/austr.txt';
    [XC, YC] = continent(R, uk, vk, s0, proj, file);
    plot(XC, YC,'b');

    % Draw boundary
    [XB, YB] = boundary(R, uk, vk, s0, proj, ub, vb);
    % Cutting lines
    plot(XB, YB,'r');
end