clc
clear
format long g

% Common parameters
proj = @gnom;
s0 = 0;
Du = 10 *pi/180;
Dv = Du;
du = pi/180;
dv = du;
R = 6378 * 1000;

% Boundary points
us = 35.2644 *pi/180;
uj = -us;

% Face 1 (north)
    % Input parameters    
    uk = pi/2;
    vk = 0;

    % Graticule
    umin = 30*pi/180;
    umax = pi/2;
    vmin = -pi;
    vmax = pi;
    
    % Boundary points (E, F, G, H, E)
    ub = [us, us, us, us, us];
    vb = [0, pi/2, pi, 3/2*pi, 0];
    
    % GLobe face
    subplot(2, 3, 1);
    globeFace(umin, umax, vmin, vmax, Du, Dv, du, dv, R, uk, vk, s0, proj, ub, vb)

% Face 2
    % Input parameters    
    uk = 0;
    vk = 45*pi/180;

    % Graticule
    umin = -70*pi/180;
    umax = 70*pi/180;
    vmin = -100*pi/180;
    vmax = 100*pi/180;

    % Boundary points (E, A, B, F, E)
    ub = [us, uj, uj, us, us];
    vb = [0, 0, pi/2, pi/2, 0];
    
    % GLobe face
    subplot(2, 3, 2);
    globeFace(umin, umax, vmin, vmax, Du, Dv, du, dv, R, uk, vk, s0, proj, ub, vb)

% Face 3
    % Input parameters    
    uk = 0;
    vk = 135*pi/180;

    % Graticule
    umin = -70*pi/180;
    umax = 70*pi/180;
    vmin = 10*pi/180;
    vmax = 200*pi/180;

    % Boundary points (F, B, C, G, F)
    ub = [us, uj, uj, us, us];
    vb = [pi/2, pi/2, pi, pi, pi/2];
    
    % GLobe face
    subplot(2, 3, 3);
    globeFace(umin, umax, vmin, vmax, Du, Dv, du, dv, R, uk, vk, s0, proj, ub, vb)

% Face 4
    % Input parameters    
    uk = 0;
    vk = 225*pi/180;

    % Graticule
    umin = -70*pi/180;
    umax = 70*pi/180;
    vmin = 100*pi/180;
    vmax = 290*pi/180;

    % Boundary points (G, C, D, H, G)
    ub = [us, uj, uj, us, us];
    vb = [pi, pi, 3/2*pi, 3/2*pi, pi];
    
    % GLobe face
    subplot(2, 3, 4);
    globeFace(umin, umax, vmin, vmax, Du, Dv, du, dv, R, uk, vk, s0, proj, ub, vb)
    
% Face 5
    % Input parameters    
    uk = 0;
    vk = 315*pi/180;

    % Graticule
    umin = -70*pi/180;
    umax = 70*pi/180;
    vmin = 190*pi/180;
    vmax = 380*pi/180;

    % Boundary points (H, D, A, E, H)
    ub = [us, uj, uj, us, us];
    vb = [3/2*pi, 3/2*pi, 0, 0, 3/2*pi];
    
    % GLobe face
    subplot(2, 3, 5);
    globeFace(umin, umax, vmin, vmax, Du, Dv, du, dv, R, uk, vk, s0, proj, ub, vb)

% Face 6 (south)
    % Input parameters    
    uk = -pi/2;
    vk = 0;
    
    % Graticule
    umin = -pi/2;
    umax = -30*pi/180;
    vmin = -pi;
    vmax = pi;

    % Boundary points (A, B, C, D, A)
    ub = [uj, uj, uj, uj, uj];
    vb = [0, pi/2, pi, 3/2*pi, 0];
    
    % GLobe face
    subplot(2, 3, 6);
    globeFace(umin, umax, vmin, vmax, Du, Dv, du, dv, R, uk, vk, s0, proj, ub, vb)